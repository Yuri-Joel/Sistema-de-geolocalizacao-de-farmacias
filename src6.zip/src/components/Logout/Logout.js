
export const Terminar = ()=>{

    localStorage.removeItem('usuario')
}