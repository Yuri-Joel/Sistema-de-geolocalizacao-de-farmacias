import React from 'react'
import { BrowserRouter, Routes } from 'react-router-dom'

function Approutes() {
  return (
      <BrowserRouter>
         <Routes>
            

         </Routes>
      </BrowserRouter>
  )
}

export default Approutes
